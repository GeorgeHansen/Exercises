import javax.swing.*;
import java.awt.*;
//import java.awt.event.*;

public class PoolPartyMain
{
   public static void main(String[] args) throws Exception
   {
     PoolLogin log = new PoolLogin();  //runs the login class which will in turn call the other classes when prompted
     //Add add = new Add();
     // PaymentInfo pi = new PaymentInfo();
     
      
   }
}